﻿using FacilityServices;
using System;
using System.ServiceModel;

namespace FacilityServiceHost
{
    class Program
    {
        static void Main(string[] args)
        {
            using (ServiceHost host = new ServiceHost(typeof(FacilityService)))
            {
                host.Open();
                Console.WriteLine("Hosted Facility Service @ " + DateTime.Now.ToString());
                Console.ReadLine();
            }
        }
    }
}
