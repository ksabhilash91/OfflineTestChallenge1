﻿namespace FacilityServices
{
    public class DoorDetails
    {
        private DoorStatus _statusOfDoor;
        public DoorStatus StatusOfDoor
        {
            get { return _statusOfDoor; }
            set
            {
                _statusOfDoor = value;
            }
        }

        private LockStatus _statusOfLock;
        public LockStatus StatusOfLock
        {
            get { return _statusOfLock; }
            set
            {
                _statusOfLock = value;
            }
        }


        private string _doorName = "NewDoor";
        public string DoorName
        {
            get { return _doorName; }
            set
            {
                _doorName = value;
            }
        }
    }

    public enum DoorStatus
    {
        Close,
        Open,

    }

    public enum LockStatus
    {
        Locked,
        Unlocked
    }
}
