﻿using System.Collections.Generic;
using System.ServiceModel;

namespace FacilityServices
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "FacilityService" in both code and config file together.
    [ServiceBehavior(ConcurrencyMode = ConcurrencyMode.Multiple, InstanceContextMode = InstanceContextMode.PerSession)]
    public class FacilityService : IFacilityService
    {
        private static object lockThis = new object();
        public static List<DoorDetails> LstDoorDetails;

        public delegate void OnDoorDetailsUpdated(List<DoorDetails> updatedDoorDetails);
        public static event OnDoorDetailsUpdated OnDoorDetailsUpdatedEvent = null;

        public FacilityService()
        {
            OnDoorDetailsUpdatedEvent += FacilityService_OnDoorDetailsUpdatedEvent;
            if (LstDoorDetails == null)
            {
                LstDoorDetails = new List<DoorDetails>();
                LstDoorDetails.Add(new DoorDetails() { DoorName = "Door1", StatusOfDoor = DoorStatus.Close, StatusOfLock = LockStatus.Locked });
                LstDoorDetails.Add(new DoorDetails() { DoorName = "Door2", StatusOfDoor = DoorStatus.Open, StatusOfLock = LockStatus.Unlocked });
            }
        }

        private void FacilityService_OnDoorDetailsUpdatedEvent(List<DoorDetails> bindableDoorDetails)
        {
            OperationContext.Current.GetCallbackChannel<IFacilityServiceCallback>().OnDoorDetailsUpdated(bindableDoorDetails);
        }

        public void GetDoorDetails()
        {
            OperationContext.Current.GetCallbackChannel<IFacilityServiceCallback>().OnGetDoorDetails(LstDoorDetails);
        }

        public void SaveDoorDetails(List<DoorDetails> doorDetailsFromClient)
        {
            lock (lockThis)
            {
                LstDoorDetails.Clear();
                LstDoorDetails = new List<FacilityServices.DoorDetails>(doorDetailsFromClient);
                OnDoorDetailsUpdatedEvent(LstDoorDetails);
            }
        }
    }
}
