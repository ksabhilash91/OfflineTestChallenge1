﻿using System.Collections.Generic;
using System.ServiceModel;

namespace FacilityServices
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IFacilityService" in both code and config file together.
    [ServiceContract(CallbackContract = typeof(IFacilityServiceCallback))]
    public interface IFacilityService
    {
        [OperationContract(IsOneWay = true)]
        void GetDoorDetails();

        [OperationContract(IsOneWay = true)]
        void SaveDoorDetails(List<DoorDetails> doorDetailsFromClient);
    }

    [ServiceContract]
    public interface IFacilityServiceCallback
    {
        [OperationContract(IsOneWay = true)]
        void OnGetDoorDetails(List<DoorDetails> doorDetails);

        [OperationContract(IsOneWay = true)]
        void OnDoorDetailsUpdated(List<DoorDetails> doorDetails);
    }
}
