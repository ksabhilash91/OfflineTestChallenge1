﻿using FacilityClient.FacilityServiceReference;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace FacilityClient.Model
{
    [CallbackBehaviorAttribute(UseSynchronizationContext = false)]
    public class FacilityData : IFacilityServiceCallback
    {
        public delegate void OnDoorDetailsReceived(List<BindableDoorDetails> bindableDoorDetails);
        public event OnDoorDetailsReceived OnDoorDetailsReceivedEvent = null;

        FacilityServiceReference.FacilityServiceClient FacilityClient;
        public FacilityData()
        {
            InstanceContext instanceContext = new InstanceContext(this);
            FacilityClient = new FacilityServiceReference.FacilityServiceClient(instanceContext);
        }

        public void SaveDoorDetails(List<BindableDoorDetails> doorDetailsToServer)
        {
            List<DoorDetails> lstDoorDetails = new List<DoorDetails>();
            foreach (var item in doorDetailsToServer)
            {
                lstDoorDetails.Add(
                    new DoorDetails
                    {
                        DoorName = item.DoorName,
                        StatusOfDoor = item.StatusOfDoor,
                        StatusOfLock = item.StatusOfLock
                    }
                    );
            }
            FacilityClient.SaveDoorDetails(lstDoorDetails.ToArray());
        }


        public void GetDoorDetails()
        {
            FacilityClient.GetDoorDetails();
        }

        public void OnDoorDetailsUpdated(DoorDetails[] doorDetails)
        {
            List<BindableDoorDetails> lstBindableDoorDetails = new List<Model.BindableDoorDetails>();
            foreach (var item in doorDetails)
            {
                lstBindableDoorDetails.Add(
                    new Model.BindableDoorDetails()
                    {
                        DoorName = item.DoorName,
                        IsRenameClicked = false,
                        StatusOfDoor = item.StatusOfDoor,
                        StatusOfLock = item.StatusOfLock
                    }
                    );
            }
            OnDoorDetailsReceivedEvent(lstBindableDoorDetails);
        }

        public void OnGetDoorDetails(DoorDetails[] doorDetails)
        {
            List<BindableDoorDetails> lstBindableDoorDetails = new List<Model.BindableDoorDetails>();
            foreach (var item in doorDetails)
            {
                lstBindableDoorDetails.Add(
                    new Model.BindableDoorDetails()
                    {
                        DoorName = item.DoorName,
                        IsRenameClicked = false,
                        StatusOfDoor = item.StatusOfDoor,
                        StatusOfLock = item.StatusOfLock
                    }
                    );
            }
            OnDoorDetailsReceivedEvent(lstBindableDoorDetails);
        }
    }
}
