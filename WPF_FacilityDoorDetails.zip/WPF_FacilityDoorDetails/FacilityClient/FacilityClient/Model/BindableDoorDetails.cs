﻿using FacilityClient.FacilityServiceReference;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FacilityClient.Model
{
    public class BindableDoorDetails : INotifyPropertyChanged
    {

        private DoorStatus _statusOfDoor;

        public DoorStatus StatusOfDoor
        {
            get { return _statusOfDoor; }
            set
            {
                _statusOfDoor = value;
                RaisePropertyChanged(nameof(StatusOfDoor));
            }
        }

        private LockStatus _statusOfLock;

        public LockStatus StatusOfLock
        {
            get { return _statusOfLock; }
            set
            {
                _statusOfLock = value;
                RaisePropertyChanged(nameof(StatusOfLock));
            }
        }


        private string _doorName = "New Door";


        public string DoorName
        {
            get { return _doorName; }
            set
            {
                _doorName = value;
                RaisePropertyChanged(nameof(DoorName));
            }
        }

        private bool _isRenameClicked;

        public bool IsRenameClicked
        {
            get { return _isRenameClicked; }
            set
            {
                _isRenameClicked = value;
                RaisePropertyChanged(nameof(IsRenameClicked));
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        private void RaisePropertyChanged(string property)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(property));
            }
        }

    }
}
