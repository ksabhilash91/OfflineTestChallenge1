﻿using FacilityClient.FacilityServiceReference;
using FacilityClient.Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Threading;

namespace FacilityClient.ViewModel
{
    public class FacilityViewModel : INotifyPropertyChanged
    {


        private ObservableCollection<BindableDoorDetails> _lstDoorDetails;

        private bool _isDoorDetailsModified = false;

        public bool IsDoorDetailsModified
        {
            get { return _isDoorDetailsModified; }
            set
            {
                _isDoorDetailsModified = value;
                if (_isDoorDetailsModified)
                {
                    SaveChangesCommand.RaiseCanExecuteChanged();
                }
            }
        }


        public DelegateCommand DoorOpenCloseCommand { get; set; }

        public DelegateCommand DoorLockUnlockCommand { get; set; }

        public DelegateCommand RenameDoorCommand { get; set; }

        public DelegateCommand AddNewDoorCommand { get; set; }

        public DelegateCommand DeleteDoorCommand { get; set; }

        public DelegateCommand RefreshDetailsCommand { get; set; }
        public DelegateCommand SaveChangesCommand { get; set; }

        public ObservableCollection<BindableDoorDetails> LstDoorDetails
        {
            get { return _lstDoorDetails; }
            set
            {
                _lstDoorDetails = value;
                RaisePropertyChanged(nameof(LstDoorDetails));
            }
        }

        private FacilityData FacilityDataObj;


        private BindableDoorDetails _selectedDoorDetail;
        public BindableDoorDetails SelectedDoorDetail
        {
            get { return _selectedDoorDetail; }
            set
            {
                _selectedDoorDetail = value;
                RaisePropertyChanged(nameof(SelectedDoorDetail));
                RenameDoorCommand.RaiseCanExecuteChanged();
                DeleteDoorCommand.RaiseCanExecuteChanged();
            }
        }


        public FacilityViewModel()
        {
            DoorOpenCloseCommand = new DelegateCommand(OnDoorOpenClose, CanDoorOpenClose);
            DoorLockUnlockCommand = new DelegateCommand(OnDoorLockUnlock, CanDoorLockUnlock);
            RenameDoorCommand = new DelegateCommand(OnRenameDoor, CanRenameDoor);
            AddNewDoorCommand = new DelegateCommand(OnAddNewDoor, CanAddNewDoor);
            DeleteDoorCommand = new DelegateCommand(OnDeleteDoor, CanDeleteDoor);
            RefreshDetailsCommand = new DelegateCommand(OnRefreshDetails, CanRefreshDetails);
            SaveChangesCommand = new DelegateCommand(OnSaveChanges, CanSaveChanges);
            FacilityDataObj = new Model.FacilityData();
            FacilityDataObj.OnDoorDetailsReceivedEvent += FacilityDataObj_OnDoorDetailsReceivedEvent;
            FacilityDataObj.GetDoorDetails();
        }

        private void FacilityDataObj_OnDoorDetailsReceivedEvent(List<BindableDoorDetails> bindableDoorDetails)
        {
            Application.Current.Dispatcher.BeginInvoke
                (DispatcherPriority.Normal,
                 new Action(() =>
                 {
                     if (LstDoorDetails != null)
                     {
                         LstDoorDetails.Clear();
                     }
                     LstDoorDetails = new ObservableCollection<BindableDoorDetails>(bindableDoorDetails);
                 }
                 ));
        }

        private void OnRefreshDetails(object parameter)
        {
            FacilityDataObj.GetDoorDetails();
            IsDoorDetailsModified = false;
        }

        private bool CanRefreshDetails(object parameter)
        {
            return true;
        }

        private void OnSaveChanges(object parameter)
        {
            FacilityDataObj.SaveDoorDetails(LstDoorDetails.ToList());
            IsDoorDetailsModified = false;
        }

        private bool CanSaveChanges(object parameter)
        {
            return IsDoorDetailsModified;
        }

        private void OnDoorOpenClose(object parameter)
        {
            BindableDoorDetails doorDetail = (parameter as BindableDoorDetails);
            switch (doorDetail.StatusOfDoor)
            {
                case DoorStatus.Open:
                    doorDetail.StatusOfDoor = DoorStatus.Close;
                    break;
                case DoorStatus.Close:
                    doorDetail.StatusOfDoor = DoorStatus.Open;
                    break;
                default:
                    break;
            }
            IsDoorDetailsModified = true;
        }

        private bool CanDoorOpenClose(object parameter)
        {
            if (parameter != null)
            {
                return (parameter as BindableDoorDetails).StatusOfLock == LockStatus.Unlocked;
            }
            return true;
        }

        private void OnDoorLockUnlock(object parameter)
        {
            BindableDoorDetails doorDetail = (parameter as BindableDoorDetails);
            switch (doorDetail.StatusOfLock)
            {
                case LockStatus.Locked:
                    doorDetail.StatusOfLock = LockStatus.Unlocked;
                    break;
                case LockStatus.Unlocked:
                    doorDetail.StatusOfLock = LockStatus.Locked;
                    break;
                default:
                    break;
            }
            IsDoorDetailsModified = true;
        }

        private bool CanDoorLockUnlock(object parameter)
        {
            if (parameter != null)
            {
                return (parameter as BindableDoorDetails).StatusOfDoor == DoorStatus.Close;
            }
            return true;
        }

        private void OnRenameDoor(object parameter)
        {
            (parameter as BindableDoorDetails).IsRenameClicked = true;
            IsDoorDetailsModified = true;
        }

        private bool CanRenameDoor(object parameter)
        {
            return SelectedDoorDetail != null;
        }
        private void OnAddNewDoor(object parameter)
        {
            LstDoorDetails.Add(new BindableDoorDetails());
            IsDoorDetailsModified = true;
        }

        private bool CanAddNewDoor(object parameter)
        {
            return true;
        }
        private void OnDeleteDoor(object parameter)
        {
            LstDoorDetails.Remove((BindableDoorDetails)parameter);
            IsDoorDetailsModified = true;
        }

        private bool CanDeleteDoor(object parameter)
        {
            return SelectedDoorDetail != null;
        }

        public event PropertyChangedEventHandler PropertyChanged;
        private void RaisePropertyChanged(string property)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(property));
            }
        }

    }
}
